<template>
  <div class="demo-space-x">
    <VAvatar color="primary">
      <VIcon
        size="20"
        icon="tabler-home"
      />
    </VAvatar>

    <VAvatar color="secondary">
      <VIcon
        color="white"
        size="20"
        icon="tabler-cloud"
      />
    </VAvatar>

    <VAvatar color="success">
      <VIcon
        size="20"
        icon="tabler-bell"
      />
    </VAvatar>

    <VAvatar color="info">
      <VIcon
        size="20"
        icon="tabler-user"
      />
    </VAvatar>

    <VAvatar color="warning">
      <VIcon
        size="20"
        icon="tabler-alert-circle"
      />
    </VAvatar>

    <VAvatar color="error">
      <VIcon
        size="20"
        icon="tabler-message"
      />
    </VAvatar>
  </div>
</template>

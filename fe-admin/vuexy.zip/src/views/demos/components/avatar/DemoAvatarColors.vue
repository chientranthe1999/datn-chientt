<template>
  <div class="demo-space-x">
    <VAvatar color="primary">
      <span>PI</span>
    </VAvatar>

    <VAvatar color="secondary">
      <span class="text-white">SE</span>
    </VAvatar>

    <VAvatar color="success">
      <span>SU</span>
    </VAvatar>

    <VAvatar color="info">
      <span>IN</span>
    </VAvatar>

    <VAvatar color="warning">
      <span>WA</span>
    </VAvatar>

    <VAvatar color="error">
      <span>ER</span>
    </VAvatar>
  </div>
</template>

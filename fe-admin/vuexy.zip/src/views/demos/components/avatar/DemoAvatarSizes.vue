<template>
  <div class="demo-space-x">
    <VAvatar
      color="primary"
      size="x-small"
    >
      <small>PI</small>
    </VAvatar>

    <VAvatar
      color="secondary"
      size="small"
    >
      <span>PI</span>
    </VAvatar>

    <VAvatar color="success">
      <span>PI</span>
    </VAvatar>

    <VAvatar
      color="info"
      size="large"
    >
      <span class="text-h6 text-white">PI</span>
    </VAvatar>

    <VAvatar
      color="error"
      size="x-large"
    >
      <span class="text-h5 text-white">PI</span>
    </VAvatar>
  </div>
</template>

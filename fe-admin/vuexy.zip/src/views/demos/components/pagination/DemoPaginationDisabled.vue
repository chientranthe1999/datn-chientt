<template>
  <VPagination
    :length="5"
    disabled
  />
</template>

<template>
  <div class="d-flex flex-column gap-4">
    <!-- Default -->
    <div>
      <VTabs>
        <VTab>Home</VTab>
        <VTab>Service</VTab>
        <VTab>Account</VTab>
      </VTabs>
      <VDivider />
    </div>

    <!-- Center -->
    <div>
      <VTabs centered>
        <VTab>Home</VTab>
        <VTab>Service</VTab>
        <VTab>Account</VTab>
      </VTabs>
      <VDivider />
    </div>

    <!-- Right -->
    <div>
      <VTabs end>
        <VTab>Home</VTab>
        <VTab>Service</VTab>
        <VTab>Account</VTab>
      </VTabs>
      <VDivider />
    </div>
  </div>
</template>

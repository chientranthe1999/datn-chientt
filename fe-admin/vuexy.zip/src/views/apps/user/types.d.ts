export interface UserParams {
  q: string,
  role: string,
  plan: string,
  status: string,
  perPage: number,
  currentPage: number,
}
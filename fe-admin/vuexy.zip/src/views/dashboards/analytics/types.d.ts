export interface ProjectParams {
  q?: string,
  perPage: number,
  currentPage: number,
}

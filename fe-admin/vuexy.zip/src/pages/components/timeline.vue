<template>
  <VRow>
    <VCol
      cols="12"
      md="6"
    >
      <TimelineBasic />
    </VCol>

    <VCol
      cols="12"
      md="6"
    >
      <TimelineCard />
    </VCol>

    <VCol cols="12">
      <TimelineWithIcons />
    </VCol>
  </VRow>
</template>
